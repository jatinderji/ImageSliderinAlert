package com.jatin.imagesliderinalert;

import android.app.Dialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.smarteist.autoimageslider.SliderView;

public class MainActivity extends AppCompatActivity {

    Button btnShow;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnShow = findViewById(R.id.btnShow);
        btnShow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {

                final Dialog dialog = new Dialog(MainActivity.this);
                dialog.setContentView(R.layout.custom);
                //SliderView sliderView = dialog.findViewById(R.id.imageSlider);
                dialog.show();

            }
        });
    }
}
